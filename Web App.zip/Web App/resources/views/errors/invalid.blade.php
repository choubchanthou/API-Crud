


<!DOCTYPE html>
<html lang="<?= app()->getLocale() ?>" ng-app="productRecords">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?= csrf_token() ?>">

    <title><?= config('app.name', 'Laravel') ?></title>

    <!-- Styles -->
    <link href="<?= asset('css/bootstrap.css')?>" rel="stylesheet">
   
</head>
<body>


<div class="container">
    <div class="row">
        <div class="col-md-8">
            <h1>Error exception....</h1>
        </div>
    </div>

</div>

    <script src="<?= asset('js/jquery.min.js') ?>"></script>
    <script src="<?= asset('js/bootstrap.js') ?>"></script>

    <!-- AngularJS Application Scripts -->
    <script src="<?= asset('app/app.js') ?>"></script>
    <script src="<?= asset('app/controllers/products.js') ?>"></script>




</body>
</html>
