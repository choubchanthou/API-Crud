<html lang="en">
<head>
    <title>Import - Export Laravel 5</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >
</head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Import - Export in Excel and CSV Laravel 5</a>
            </div>
        </div>
    </nav>
    <div class="container">
        @if (session('status'))
            <div class="alert alert-success">
                <h4>{{ session('status') }}</h4>
            </div>
        @endif
        @if (session('failed'))
            <div class="alert alert-danger">
                <h4>{{ session('failed') }}</h4>
            </div>
        @endif
        <form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;background: #ccc;height: 100px" action="{{ URL::to('/uploads/save') }}" class="form-horizontal" method="post" enctype="multipart/form-data">
            <input type="file" name="file" />
            {!!   csrf_field() ; !!} 
            <button class="btn btn-primary" type="submit">Import File</button>
        </form>
        
    </div>
</body>
</html>