


<!DOCTYPE html>
<html lang="<?= app()->getLocale() ?>" ng-app="productRecords">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo csrf_token() ?>">

    <title><?= config('app.name', 'Laravel') ?></title>

    <!-- Styles -->
    <link href="<?= asset('css/bootstrap.css')?>" rel="stylesheet">
    <style type="text/css">
        #mydiv {  
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index:1000;
    background-color:grey;
    opacity: .8;
 }

.ajax-loader {
    position: absolute;
    left: 50%;
    top: 50%;
    margin-left: -32px; /* -1 * image width / 2 */
    margin-top: -32px;  /* -1 * image height / 2 */
    display: block;     
}

    </style>
</head>
<body ng-controller="productsController">
<div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?= url('/') ?>">
                       Laravel
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                      <li><a href="<?=asset('/')?>">Home</a></li>
                      <li><a href="<?=asset('/view/').'/'.App\Api::encrypt_tb('tbl_users')?>">Users</a></li>
                      <li><a href="<?=asset('/view/').'/'.App\Api::encrypt_tb('tbl_products')?>">Products</a></li>
                      <li><a href="<?=asset('/view/').'/'.App\Api::encrypt_tb('tbl_books')?>">Books</a></li>
                      <li><a href="#">Abouts</a></li>
                    </ul>
                </div>
            </div>
        </nav>
</div>

<div class="container">
    <h2>Products Database</h2>
        <div>

            <!-- Table-to-load-the-data Part -->
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Note</th>
                        <th><button id="btn-add" class="btn btn-primary btn-xs" ng-click="toggle('add', 0)">Add New Products</button></th>
                    </tr>
                </thead>
                <tbody>
                    <tr dir-paginate="p in products | itemsPerPage: 5">
                        <td>{{p.id}}</td>
                        <td>{{p.product_name}}</td>
                        <td>{{p.price}}</td>
                        <td>{{p.qty}}</td>
                        <td></td>
                        <td>
                            <button class="btn btn-default btn-xs btn-detail" ng-click="toggle('edit', p.id)">Edit</button>
                            <button class="btn btn-danger btn-xs btn-delete" ng-click="confirmDelete(p.id)">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <dir-pagination-controls></dir-pagination-controls>
            <!-- End of Table-to-load-the-data Part -->
            <!-- Modal (Pop up when detail button clicked) -->
            <!-- Modal (Pop up when detail button clicked) -->
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" ng-click="test()" id="myModalLabel">{{form_title}}</h4>
                        </div>
                        <div class="modal-body">
                            <form name="frmProduct" class="form-horizontal" novalidate="">
                                <?= csrf_field() ?>
                                <div class="form-group error">
                                    <label for="inputEmail3" class="col-sm-3 control-label">Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control has-error" id="product_name" name="product_name" placeholder="Fullname" value="{{product_name }}" 
                                        ng-model="data.product_name">
                                        <span class="help-inline" 
                                        ng-show="frmProduct.name.$invalid && frmProduct.name.$touched">Name field is required</span>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputEmail3" class="col-sm-3 control-label">Price</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="price" name="price" placeholder="1200" value="{{price}}" 
                                        ng-model="data.price" ng-required="true">
                                        <span class="help-inline" 
                                        ng-show="frmProduct.price.$invalid && frmProduct.price.$touched">Valid Price field is required</span>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputEmail3" class="col-sm-3 control-label">Qty</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="qty" name="qty" placeholder="Position" value="{{position}}" 
                                        ng-model="data.qty" ng-required="true">
                                    <span class="help-inline" 
                                        ng-show="frmProducts.qty.$invalid && frmProducts.qty.$touched">Position field is required</span>
                                    </div>
                                </div>

                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" id="btn-save" ng-click="save(modalstate, id)" ng-disabled="frmProduct.$invalid">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="mydiv">
    <img src="<?= asset("images/loader.gif") ?>" class="ajax-loader"/>
</div>

    <!-- Scripts -->
    <!-- Load Javascript Libraries (AngularJS, JQuery, Bootstrap) -->
    <script src="<?= asset('app/lib/angular/angular.min.js') ?>"></script>
    <script src="<?= asset('js/jquery.min.js') ?>"></script>
    <script src="<?= asset('js/bootstrap.js') ?>"></script>

    <!-- AngularJS Application Scripts -->
    <script src="<?= asset('app/app.js') ?>"></script>
    <script src="<?= asset('app/controllers/products.js') ?>"></script>
    <script type="text/javascript">

        $('#mydiv').show(); 
        $('#mydiv').hide(100); 
    </script>
    <script type="text/javascript" src="<?= asset("/js/angular-local-storage.js") ?>"></script>
    <script type="text/javascript" src="<?= asset("/js/dirPagination.js") ?>"></script>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    </script>



</body>
</html>
