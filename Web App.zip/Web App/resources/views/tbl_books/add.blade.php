@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">New Book</div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="{{ url('/save') }}">
                        {{ csrf_field() }}
                        <input type="hidden" name="table" value="{{App\Api::encrypt_tb('tbl_books')}}"/>
                        <input type="hidden" name="rules" value="{{App\Api::encrypt_tb('book_title,required|unique:tbl_books,author,required')}}">
                        <div class="form-group{{ $errors->has('book_title') ? ' has-error' : '' }}">
                            <label for="book_title" class="col-md-4 control-label">Book Title</label>

                            <div class="col-md-6">
                                <input id="book_title" type="text" class="form-control" name="book_title" value="{{ old('book_title') }}">
                                @if ($errors->has('book_title'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('book_title') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('author') ? ' has-error' : '' }}">
                            <label for="author" class="col-md-4 control-label">Author</label>

                            <div class="col-md-6">
                                <input id="author" type="text" class="form-control" name="author" value="{{ old('author') }}">

                                @if ($errors->has('author'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('author') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Save
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection