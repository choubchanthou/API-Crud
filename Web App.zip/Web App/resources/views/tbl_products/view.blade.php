@extends('layouts.app')

@section('content')
<div class="container">
<!-- Table-to-load-the-data Part -->
    <h2>Products Management</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th><a href="{{ url('/add/').'/'.App\Api::encrypt_tb('tbl_products')}}" class="btn btn-primary btn-xs">Add Products</th>           
                
                    </tr>
                </thead>
                <tbody>
                    @foreach($tbl_products as $p)
                    <tr>
                        <td>{{ $p->id }}</td>
                        <td>{{ $p->product_name }}</td>
                        <td>{{ $p->price }}</td>
                        <td>{{ $p->qty }}</td>
                        <td>
                            <a class="btn btn-default btn-xs btn-detail" href="{{url('/').'/'.$p->id.'/edit/'.App\Api::encrypt_tb('tbl_products')}}">Edit</a>
                            <a class="btn btn-danger btn-xs btn-delete" href="{{url('/').'/'.$p->id.'/delete/'.App\Api::encrypt_tb('tbl_products')}}" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            {{$tbl_products->links()}}
</div>

@endsection     