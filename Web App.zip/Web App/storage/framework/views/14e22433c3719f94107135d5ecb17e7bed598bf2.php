<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">New Book</div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('/save')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="table" value="tbl_books"/>
                        <input type="hidden" name="rules" value="book_title,required|regex:/(^[A-Za-z0-9 ]+$)+/|unique:tbl_books,author,required">
                        <div class="form-group<?php echo e($errors->has('book_title') ? ' has-error' : ''); ?>">
                            <label for="book_title" class="col-md-4 control-label">Book Title</label>

                            <div class="col-md-6">
                                <input id="book_title" type="text" class="form-control" name="book_title" value="<?php echo e(old('book_title')); ?>">
                                <?php if($errors->has('book_title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('book_title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('author') ? ' has-error' : ''); ?>">
                            <label for="author" class="col-md-4 control-label">Author</label>

                            <div class="col-md-6">
                                <input id="author" type="text" class="form-control" name="author" value="<?php echo e(old('author')); ?>">

                                <?php if($errors->has('author')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('author')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Save
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>