<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add New User</div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('/save')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="table" value="tbl_users"/>
                        
                        <input type="hidden" name="rules" value="name,required|regex:/(^[A-Za-z0-9 ]+$)+/,email,required|unique:tbl_users|max:255|email">

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="price" class="col-md-4 control-label">Gender</label>

                            <div class="col-md-6">
                                <div class="radio">
                                  <label><input type="radio" name="gender" checked="checked" value="1">Male</label>
                                </div>
                                <div class="radio">
                                  <label><input type="radio" name="gender" value="0">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="group_id">User Group:</label>
                          <div class="col-md-6">
                            <select class="form-control" name="group_id" id="group_id">
                                <option value="1">Super Admin</option>
                                <option value="2">Subscriber</option>
                                <option value="3">Editor</option>
                                <option value="4">Stuff</option>
                              </select>
                          </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="price" class="col-md-4 control-label">Email</label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <input type="hidden" name="created_at" value="<?php echo e(date('Y-m-d H:i:s')); ?>">
                                <input type="hidden" name="updated_at" value="<?php echo e(date('Y-m-d H:i:s')); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Save
                                </button>
                                <a class="btn btn-primary" href="<?php echo e(url('/view').'/'.App\Api::encrypt_tb('tbl_users')); ?>">
                                    Back
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>