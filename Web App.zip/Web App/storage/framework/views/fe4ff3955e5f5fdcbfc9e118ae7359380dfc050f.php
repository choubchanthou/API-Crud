<?php $__env->startSection('content'); ?>
<div class="container">
<!-- Table-to-load-the-data Part -->
    <h2>Book Management</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th><a href="<?php echo e(url('/addbook')); ?>" class="btn btn-primary btn-xs">Add Book</th>           
                
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($b->id); ?></td>
                        <td><?php echo e($b->book_title); ?></td>
                        <td><?php echo e($b->author); ?></td>
                        <td>
                            <a class="btn btn-default btn-xs btn-detail" href="<?php echo e(url('/books').'/'.$b->id.'/edit'); ?>">Edit</a>
                            <a class="btn btn-danger btn-xs btn-delete" href="<?php echo e(url('/').'/'.$b->id.'/delete/tbl_books'); ?>" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($books->links()); ?>

</div>

<?php $__env->stopSection(); ?>     
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>