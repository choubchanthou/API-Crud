<?php $__env->startSection('content'); ?>
<div class="container">
<!-- Table-to-load-the-data Part -->
    <h2>User Management</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th><a href="<?php echo e(url('/add/').'/'.App\Api::encrypt_tb('tbl_users')); ?>" class="btn btn-primary btn-xs">Add User</th>           
                
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tbl_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($u->id); ?></td>
                        <td><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->email); ?></td>
                
                        <td>
                            <a class="btn btn-default btn-xs btn-detail" href="<?php echo e(url('/').'/'.$u->id.'/edit/'.App\Api::encrypt_tb('tbl_users')); ?>">Edit</a>
                            <a class="btn btn-danger btn-xs btn-delete" href="<?php echo e(url('/').'/'.$u->id.'/delete/'.App\Api::encrypt_tb('tbl_users')); ?>" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($tbl_users->links()); ?>

</div>

<?php $__env->stopSection(); ?>     
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>