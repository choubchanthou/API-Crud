<?php $__env->startSection('content'); ?>
<div class="container">
<!-- Table-to-load-the-data Part -->
    <h2>Products Management</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th><a href="<?php echo e(url('/addproduct')); ?>" class="btn btn-primary btn-xs">Add Products</th>           
                
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($p->id); ?></td>
                        <td><?php echo e($p->product_name); ?></td>
                        <td><?php echo e($p->price); ?></td>
                        <td><?php echo e($p->qty); ?></td>
                        <td>
                            <a class="btn btn-default btn-xs btn-detail" href="<?php echo e(url('/product').'/'.$p->id.'/edit'); ?>">Edit</a>
                            <a class="btn btn-danger btn-xs btn-delete" href="<?php echo e(url('/').'/'.$p->id.'/delete/tbl_products'); ?>" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($products->links()); ?>

</div>

<?php $__env->stopSection(); ?>     
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>