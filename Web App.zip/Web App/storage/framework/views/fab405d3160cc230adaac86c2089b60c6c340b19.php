<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Edit Product</div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('/update')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="table" value="tbl_products"/>
                        <input type="hidden" name="id" value="<?php echo e($products->id); ?>">
                        <input type="hidden" name="rules" value="product_name,required,price,required|numeric">
                        <div class="form-group<?php echo e($errors->has('product_name') ? ' has-error' : ''); ?>">
                            <label for="product_name" class="col-md-4 control-label">Product Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="product_name" value="<?php echo e($products->product_name); ?>">

                                <?php if($errors->has('product_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('product_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                            <label for="price" class="col-md-4 control-label">Price</label>

                            <div class="col-md-6">
                                <input id="price" type="text" class="form-control" name="price" value="<?php echo e($products->price); ?>">

                                <?php if($errors->has('price')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('price')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        

                        <div class="form-group<?php echo e($errors->has('qty') ? ' has-error' : ''); ?>">
                            <label for="qty" class="col-md-4 control-label">QTY</label>

                            <div class="col-md-6">
                                <input id="qty" type="text" class="form-control" name="qty" value="<?php echo e($products->qty); ?>">
                                <?php if($errors->has('qty')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('qty')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Save
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>