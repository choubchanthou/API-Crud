<!doctype html>
<htm <?php echo app('translator')->getFromJson("en"); ?>>
    <head>
        <title>Upload File</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.css')); ?>"/>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/dropzone.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/custom.css')); ?>">

    </head>
    <body>
    <div class="container">
        <form action="/file-upload"
              class="dropzone"
              id="my-awesome-dropzone">
            <?php echo e(csrf_field()); ?>

        </form>
        <button class="btn btn-primary" id="btn-Submit">Submit</button>
        <button class="btn btn-danger" id="removeAllImages">Remove All</button>
        <div class="row">
            <div class="col-lg-12">
                <table class="table">
                    <tbody id="preview">

                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script type="text/javascript" src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/dropzone.js')); ?>"></script>
    <script type="text/javascript">
        //var list=[];
        var id;
        Dropzone.options.myAwesomeDropzone = {
            init: function() {
                fbDropZone = this;
                $("#removeAllImages").click(function(){fbDropZone.removeAllFiles();})
                this.on("success", function(file, responseText) {
                    var obj = responseText;
                    var items = obj.items;
                    content="";
                    //list=[];
                    $.each(obj.items,function(i,item){

                              content +="<tr><td><img src='"+obj.path+ item +"' class='img img-size'/> </td><td><a href='javascript:void(0)' id='btn-remove' class='btn btn-danger' data-image='"+ obj.base_path+"' data-id='"+obj.id+"' data-name='"+item+"'>Remove</a. </td></tr>"
                              //list.push(item);


                    });
                    $("#preview").html(
                            content
                    );
                    id= obj.id;
                });
            },
            paramName: "file",
            maxFilesize: 20,
            maxFiles : 10,
            autoProcessQueue : true,
            addRemoveLinks : false,
            acceptedFiles: ".png,.jpg,.gif,.bmp,.jpeg,.pdf,.rar,.zip",
            uploadMultiple: true,

        };
        $(document).ready(function(){

            $(document).on("click",'#btn-Submit',function(){
                var id_dir;
                //var filename;
                //console.log(list);
                id_dir=$("#btn-remove").attr("data-id");
                $.ajax({
                   url: "<?= url('/save-file') ?>",
                   type:"GET",
                   data : {
                       id_dir : id_dir,
                        _token: '<?php echo e(csrf_token()); ?>'
                   },
                    success:function(respone){
                        if(respone.success){
                           $(location).attr('href', 'http://localhost:8000')
                        }
                    }
                });

            });

            $(document).on("click",'#btn-remove',function(){
                var path=$(this).attr("data-image");
                var id =$(this).attr("data-id");
                var name =$(this).attr("data-name");
                $.ajax({
                    url: "<?= url('/remove-file') ?>",
                    data: {
                        path : path,
                        name : name,
                        id : id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(result){
                        var obj = result;
                        var items = obj.items;
                        content="";
                        //list=[];
                        $.each(obj.items,function(i,item){

                            content +="<tr><td><img src='"+obj.path+ item +"' class='img img-size'/> </td><td><a href='javascript:void(0)' id='btn-remove' class='btn btn-danger' data-image='"+ obj.base_path+"' data-id='"+obj.id+"' data-name='"+item+"'>Remove</a. </td></tr>"
                                //list.push(item);

                        });
                        $("#preview").html(
                                content
                        );
                    }
                });
            });

        });

    </script>
    <script type="text/javascript">
        $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});
    </script>

    </body>
</htm>