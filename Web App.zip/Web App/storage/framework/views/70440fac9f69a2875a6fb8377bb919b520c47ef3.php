<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Edit User</div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('/update')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="table" value="tbl_users"/>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Name</label>
                            <input type="hidden" name="id" value="<?php echo e($users->id); ?>">
                            <input type="hidden" name="rules" value="name,required|regex:/(^[A-Za-z0-9 ]+$)+/,email,required|max:255|email">

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($users->name); ?>">

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="price" class="col-md-4 control-label">Gender</label>

                            <div class="col-md-6">
                                <div class="radio">
                                  <label>
                                        <input type="radio" name="gender" value="1" <?= ($users->gender== 1) ?  "checked" : "" ;  ?>>Male
                                  </label>
                                </div>
                                <div class="radio">
                                  <label><input type="radio" name="gender" value="0" <?= ($users->gender== 0) ?  "checked" : "" ;  ?>>Female </label>
                                </div>
                            </div>
                        </div>

                        <<div class="form-group">
                          <label class="col-md-4 control-label" for="group_id">User Group:</label>
                          <div class="col-md-6">
                            <select class="form-control" name="group_id" id="group_id">
                                <option value="1" <?=($users->group_id==1)?"selected":"" ?>>Super Admin</option>
                                <option value="2" <?=($users->group_id==2)?"selected":"" ?>>Subscriber</option>
                                <option value="3" <?=($users->group_id==3)?"selected":"" ?>>Editor</option>
                                <option value="4" <?=($users->group_id==4)?"selected":"" ?>>Stuff</option>
                              </select>
                          </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">email</label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="email" value="<?php echo e($users->email); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <input type="hidden" name="updated_at" value="<?php echo e(date('Y-m-d H:i:s')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Save
                                </button>
                                <a class="btn btn-danger" href="<?php echo e(url('/users')); ?>">
                                    Cancel
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>