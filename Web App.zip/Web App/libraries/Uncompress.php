<?php

namespace libraries;
use ZipArchive;
use RarArchive;
class Uncompress{

    //function fix height
    function fixHeight($fix_height, $width, $height)
    {
        $ratio = $width / $height;
        $width = $fix_height * $ratio;
        return array($width, $fix_height);
    }// end function fix height


    //function fix width image
    function fixWidth($fix_width, $width, $height)
    {
        $ratio = $height / $width;
        $height = $fix_width * $ratio;
        return array($fix_width, $height);
    }
    // end function fix with image

    // Function display Image in zip
    function ShowAllImageInZip($path, $filename)
    {
        //print_r($path.$filename);
        ignore_user_abort(true);
        set_time_limit(0); // disable the time limit for this script

        $dl_file = $filename;
        $fullPath = $path.$dl_file;
        //echo "this is zip ok <br/>";

        $zip = new ZipArchive;
        $arrbase=array();
        $arrname=array();
        $arrp=array();
        if ($zip->open($fullPath) === true)
        {
            for($i = 0; $i < $zip->numFiles; $i++)
            {
                //$zip->extractTo('path/to/extraction/', array($zip->getNameIndex($i)));
                // here you can run a custom function for the particular extracted file
                $cont_name = $zip->getNameIndex($i);
                $cont_path_parts = pathinfo($cont_name);
                $cont_ext = strtolower($cont_path_parts["extension"]);
                $allowed_ext = array("jpg","png","gif","bmp");
                //echo $cont_name;
                //echo $cont_ext;
                if (in_array($cont_ext,$allowed_ext))
                {
                    //echo $cont_ext;
                    $contents = '';
                    //echo $cont_name."<br/>";
                    $fp = $zip->getStream($cont_name);
                    if(!$fp) exit("failed\n");

                    //echo "get stream...<br/>";

                    while (!feof($fp)) {
                        $contents .= fread($fp, 2);
                    }
                    fclose($fp);

                    $b64 = base64_encode($contents);

                    list($w, $h) = getimagesizefromstring($contents);
                    //echo $w." ".$h."<br/>";
                    list($width, $height) = $this->fixWidth(600, $w, $h);
                    //echo $width." ".$height."<br/>";
                   array_push($arrbase,"data:image/".$cont_ext.";base64,".$b64);
                   array_push($arrname,$cont_name);
                }
            }
            array_push($arrp,array("base"=>$arrbase,"name"=>$arrname));
            $zip->close();
        }
        else
        {
            echo "fail open file ".$filename."<br/>";
        }
        return $arrp;
    }

    // End function display all images in zip



    // Function Remove file
    function removeFile($filename){
        if(file_exists($filename)){
            unlink($filename);
        }
        return true;
    }


    // end function remove


    function AddZip($dir,$id,$files){
        $zip= new ZipArchive;
        if ($zip->open($dir.$id, ZipArchive::CREATE) === TRUE) {
            foreach ($files as $file)
            {
                $zip->addFile($dir.$file,$file);
            }
            $zip->close();
            return true;
        } else {
            return false;
        }
    }

    // function display all images in rar

    function ShowAllImageInRar($path, $filename)
    {
        //print_r($path.$filename);
        $fullpath=$path.$filename;
        ignore_user_abort(true);
        set_time_limit(0); // disable the time limit for this script
        $rar = RarArchive::open($fullpath);
        $arrbase=array();
        $entries = $rar->getEntries();
            if ($entries) {
                sort($entries);
                for ($i = 0; $i <= count($entries) - 1; $i++) {
                    $name = $entries[$i]->getName();
                    $cont_path_parts = pathinfo($name);
                    $cont_ext = strtolower($cont_path_parts["extension"]);
                    $allowed_ext = array("jpg","png","gif","bmp");
                    //echo $cont_name;
                    //echo $cont_ext;
                    if (in_array($cont_ext,$allowed_ext)) {
                        $content = "";
                        $entry = $rar->getEntry($name);
                        if ($entry) {
                            $stream = $entry->getStream();
                            if (!$stream) exit("failed\n");

                            //echo "get stream...<br/>";
                            //read content from stream
                            while (!feof($stream)) {
                                $content .= fread($stream, 2);
                            }
                            fclose($stream);
                            // get base 64 code from content
                            $b64 = base64_encode($content);


                            list($w, $h) = getimagesizefromstring($content);
                            //echo $w." ".$h."<br/>";
                            list($width, $height) = $this->fixWidth(600, $w, $h);
                            //echo $width." ".$height."<br/>";
                            array_push($arrbase,"data:image/".$cont_ext.";base64,".$b64);

                        }
                    }
                }
            }
            else
            {
                echo "fail open file ".$filename."<br/>";
            }
        $rar->close();
        unset($rar);
        return $arrbase;
    }
    // end function display all images in rar
    //function read file sub directory
    function readDirs($path){
        $dirHandle = opendir($path);
        $items = array();
        while($item = readdir($dirHandle)) {
            $newPath = $path."/".$item;
            if(is_dir($newPath) && $item != '.' && $item != '..') {
                echo "Found Folder $newPath<br>";
                $this->readDirs($newPath);
            }
            else{
                array_push($items,$item);
            }
        }
        return $items;
    }// end function readdir



    //function unzip
    function unzip($filename,$dir,$id){
        $zip= new ZipArchive;
        // check don't have this dir 
        if(!is_dir($dir.'/'.$id)){
            // if don't have will be create here
            mkdir($dir.'/'.$id);
        }

        // read files in directory
        $items = $this->getAllImageAfterExtract($dir.'/'.$id."/");
        // check file zip
        if($zip->open($dir.'/'.$id."/".$filename) === true){
            // check have file in directory
            if(count($items)>0):
                // get each file in zip file
               for ($i = 0; $i < $zip->numFiles; $i++):
                    // get each file in directory
                    foreach ($items as $value):

                        // Check exists echo files in zip file on dir
                        if($zip->getNameIndex($i)===$value):
                            // Rename files in zip file
                            $zip->renameName($zip->getNameIndex($i),rand().$zip->getNameIndex($i));
                        endif;

                    endforeach;
                endfor; 
            endif;

            /// open zip file again after rename files in zip and before extract to 
            $zip->open($dir.'/'.$id."/".$filename);
            // extract file zip to dir with id
            $zip->extractTo($dir.'/'.$id);
            $zip->close();
            unlink($dir.'/'.$id."/".$filename);
            //print_r("hello world");
        }
    }
    // end function rar


    // function unrar
    function unrar($filename,$dir,$id){
        $rar_file = rar_open($dir.'/'.$id."/".$filename) or die("Can't open Rar archive");
        $entries = rar_list($rar_file);
        ///print_r($entries);
        // check directory exists
        if(!is_dir($dir.'/'.$id)){
            mkdir($dir.'/'.$id);
        }
        // read files in directory
        $items = $this->getAllImageAfterExtract($dir.'/'.$id."/");
        foreach ($entries as $entry) {
            if(count($items)>0){
                foreach ($items as $value) {
                    if($value===$entry->getName()){
                        $entry->extract("",$dir.'/'.$id."/".rand().$entry->getName());
                    }else{
                        $entry->extract($dir.'/'.$id."/");
                    }
                }
            }else{
                $entry->extract($dir.'/'.$id."/");

            }
 
        }
        if(rar_close($rar_file)){
            unlink($dir.'/'.$id."/".$filename);
        }

    }


    // function get all images after extract rar or zip
    function getAllImageAfterExtract($dir){
        $files= scandir($dir);
        print_r($files);
        exit();
        $images=array();
        foreach($files as $f){
            $aext= explode(".",$f);
            $ext=end($aext);
            $allowed_ext = array("jpg","png","bmp","gif");
            if(in_array($ext,$allowed_ext)){
                array_push($images,$f);
            }
        }
        return $images;
    }


    // function delete all file in dir
    public function cleanTempFilesUser($directory)
    {
        //print_r($directory);
        if(count(glob("{$directory}/*"))>0){
            foreach(glob("{$directory}/*") as $file)
            {
                if(is_dir($file)) {
                    //print_r($file);
                    //exit();
                    $this->cleanTempFilesUser($file);
                } else {
                    unlink($file);
                }
            }
        }
            rmdir($directory);
            return true;
    }
    // Function delete directory

    function deleteDir($dirPath) {
        if (! is_dir($dirPath)) {
            throw new InvalidArgumentException("$dirPath must be a directory");
        }
        if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
            $dirPath .= '/';
        }
        $files = glob($dirPath . '*', GLOB_MARK);
        foreach ($files as $file) {
            if (is_dir($file)) {
                self::deleteDir($file);
            } else {
                unlink($file);
            }
        }
        rmdir($dirPath);
    }
}