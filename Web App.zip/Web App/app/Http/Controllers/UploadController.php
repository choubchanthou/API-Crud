<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use ZipArchive;
use Libraries;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use libraries\Uncompress;

use DB;

class UploadController extends Controller
{
    //
    public $newdir;
    public function __construct()
    {
        $this->newdir=12345;
    }
    public function home(){
        session_start();
        $ziper = new Uncompress();
        //unset($_SESSION["order_id"]);
        //var_dump(isset($_SESSION["order_id"]));
        //exit();
        // clean temporary file for each users
        if(isset($_SESSION["order_id"])==true){
            //print_r($_SESSION["order_id"]);
            //print_r(base_path('storage/app/public/tmp'."/".$_SESSION['order_id']));
            //$ziper->cleanTempFilesUser("C:\\xampp\htdocs\uploads\storage/app/public/tmp/12345");
            //exit();
            if(!$ziper->cleanTempFilesUser(base_path('storage/app/public/tmp'."/".$_SESSION['order_id']))){
                die("Delete temp file failed");
            }
            session_destroy();
            unset($_SESSION["order_id"]);
        }
        // close clean temp
        return view('index');
    }
    public function removeFile(Request $request){
        $path = $request->path;
        $id = $request->id;
        $name= $request->name;
        $filename=$path."/".$id."/".$name;
        $directory=$path."/".$id."/";
        $zip = new Uncompress();
        if($zip->removeFile($filename)){
            $imglist = $zip->getAllImageAfterExtract($path.$id);
            //dd($path."/".$id);
        }
        if(count(glob("{$directory}/*"))<=0){
            rmdir($directory);
            session_destroy();
            unset($_SESSION["order_id"]);
        }
        //unset($_SESSION["order_id"]);
        return response()->json(
            [
                "items"=>$imglist,
                "path"=>asset('/storage/tmp/')."/".$id."/",
                "base_path"=>$path,
                "id" => $id
            ]
        );
    }

    public function saveFile(Request $request){
        session_start();
        $id = $request->id_dir;

        $ziper = new Uncompress;

        $filezip=$id.".zip";

        $realpath=base_path('storage/app/public')."/tmp/".$id."/";

        $newpath=base_path('storage/app/public') . '/'.$id."/";

        $files=$ziper->getAllImageAfterExtract($realpath);
        

        if($ziper->AddZip($realpath,$filezip,$files)){

            if(!is_dir($newpath)){

                        mkdir($newpath);

            }
            

            copy($realpath.$filezip,$newpath.$filezip);

            $ziper->cleanTempFilesUser($realpath);

            session_destroy();

            unset($_SESSION["order_id"]);
        }

         DB::table("tbl_images")
        ->insert(["image_title"=>$filezip,"order_id"=>$id]);
        return response()->json(["success"=>"successfuly "]);


        
    }

    public function uploadImage(Request $request)
    {
        $newdir=$this->newdir;
        session_start();
        $zip = new Uncompress();
        $uploads_dir = base_path('storage/app/public');
        //print_r($uploads_dir);
        $file=$request->file('file');
        // check file if uploaded
        if ($request->hasFile('file')) {
            if(count($file)>0){
                foreach ($file as $f) {
                        //dd($f);

                        $tmp_name = $f->getRealPath();

                        $ext=$f->getClientOriginalExtension();

                        $allowed_ext_img=array("jpg","jpeg","png","gif","bmp");

                        $name = $f->getClientOriginalName();

                        if (file_exists($uploads_dir . $name)) {

                            unlink($uploads_dir . $name);

                        }
                    // Make directory in temp using id user and check directory exists
                    if(!is_dir($uploads_dir . '/tmp/'.$newdir."/")){
                        mkdir($uploads_dir . '/tmp/'.$newdir."/");
                    }
                    $_SESSION["order_id"]=$newdir;


                        // check file allowed file extensions type
                        if($ext=='zip'){

                            // upload file from client to temp
                            copy($tmp_name, $uploads_dir . '/tmp/'.$newdir."/". $name);
                            //dd(base_path('storage/app/public') . '/example.zip');
                            //$imglist=$zip->ShowAllImageInZip($uploads_dir . '/tmp/'.$newdir."/",$name);
                            //dd(basename($tmp_name));
                            //if($zip->unzip($name,$uploads_dir.'/tmp/',$newdir)){
                                //$imglist = $zip->getAllImageAfterExtract($uploads_dir.'/tmp/'.$newdir."/");
                            //}


                            // Extract zip file to tmp folder

                            $zip->unzip($name,$uploads_dir.'/tmp',$newdir);
                            // Get all images from temp folder
                            //$imglist = $zip->getAllImageAfterExtract($uploads_dir.'/tmp/'.$newdir);

                        }else if($ext=='rar'){
                            //$ziper->unrar($name,$uploads_dir,$newdir);
                            $zip = new Uncompress();

                            // upload file from client to temp
                            copy($tmp_name, $uploads_dir . '/tmp/'.$newdir."/". $name);
                            // Extract zip file to tmp folder
                            $zip->unrar($name,$uploads_dir.'/tmp',$newdir);


                        }else if(in_array($ext,$allowed_ext_img)){
                            if(file_exists($uploads_dir . '/tmp/'.$newdir."/". $name)):
                                copy($tmp_name, $uploads_dir . '/tmp/'.$newdir."/".rand().$name);
                            else:
                                copy($tmp_name, $uploads_dir . '/tmp/'.$newdir."/". $name);
                            endif;   
                            // upload file from client to temp
                        
                        }else{
                            return "not allowed file extension";
                        }
                    $imglist=array();
                    $imglist = $zip->getAllImageAfterExtract($uploads_dir.'/tmp/'.$newdir);
                    print_r($imglist);
                    exit();
                }// close foreach
                // Get all images from temp folder

            }
        }

        return response()->json(
            [
                "items"=>$imglist,
                "path"=>asset('/storage/tmp/')."/".$newdir."/",
                "base_path"=>$uploads_dir.'/tmp/',
                "id" => $newdir
            ]
        );


    }

    //end function





}
