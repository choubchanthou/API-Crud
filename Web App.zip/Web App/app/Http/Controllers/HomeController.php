<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use DB;
use App\Api;
use Validator;
use Excel;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

/////////////////////////////////////// Call View ///////////////////////////////    
    public function index()
    {
        return view('home');
    }






///////////////////////// End Call View ////////////////////////////////////////


//////////////////// Api Complete //////////////////////////////////////////


    /// get all users

    public function openView($table){
            $table=Api::decrypt_tb($table);
            if(Schema::hasTable($table)==false){
                die('Invalid URL can\'t access');
                exit();
            }
            $model = new Api;
            $dta =$model->readWithPagin($table,5);
            return view($table.".view",[$table=>$dta]); 
       
    }
    
    

    public function openAdd($table){
        $table=Api::decrypt_tb($table);
        if(Schema::hasTable($table)==false){
                die('Invalid URL can\'t access');
                exit();
            }
        return View($table.".add");
    }
    // store Function 

    public function save(Request $request){
        $table = $request->table;
        $table=Api::decrypt_tb($table);
        $model = new Api;
        $data = $request->all();
        $rules=$model->getRules($request->rules);
        //print_r($rules);
        //exit();
        unset($data['_token']);
        unset($data['table']);
        unset($data['rules']);
        $validator=Validator::make($data,$rules);
        
        if ($validator->fails()) {
            return back()
                        ->withErrors($validator)
                        ->withInput();
        }else{
           $model->add($table,$data);
           return redirect('/view'.'/'.$table);
        }
    }


    // get user edit

    public function openEdit($id,$table){
        $tb=Api::decrypt_tb($table);
        if(Schema::hasTable($tb)==false){
                die('Invalid URL can\'t access');
                exit();
            }
        $model = new Api;
        $data = $model->readEdit($tb,$id);
        return view($tb.'.edit',[$tb=>$data[0]]);
    }


    /// Update Data Function
    public function update(Request $request){
        $table = $request->table;
        $table=Api::decrypt_tb($table);
        $id=$request->id;
        $data = $request->all();
        $model = new Api;
        $rules=$model->getRules($request->rules);
        unset($data['_token']);
        unset($data['table']);
        unset($data['id']);
        unset($data['rules']);
        $validator=Validator::make($data,$rules);
        
        if ($validator->fails()) {
            return back()
                        ->withErrors($validator)
                        ->withInput();
        }else{
            $model->updateData($table,$id,$data);
            return redirect('/add'.'/'.$table)->back()->with('status','Updated successfully...'); 
        }
    }

    /// Destory data

    public function destory($id,$table){
        $table=Api::decrypt_tb($table);
        if(Schema::hasTable($table)==false){
                die('Invalid URL can\'t access');
                exit();
            }
        $model = new Api;
        $model->remove($table,$id);
        return back();
    }



////////////////////////////////// End Api Complete //////////////////////////


///////////////////////////////// Not Complete ////////////////////////////////////
    

    public function imported(Request $request){
        //var_dump($request->hasFile('file'));
        $prices= ['ai'=>10, 'hd'=>12, 'png' => 9, 'jpg' => 20];
        $model = new Api;
       
        if($request->hasFile('file')){
            //print_r($request->file('file')->getMimeType());
            //exit();
            if($request->file('file')->getClientOriginalExtension()==='csv' && $request->file('file')->getMimeType() ==='text/plain'){
                //echo 'Hello';
                $path = $request->file('file')->getRealPath();

                $data = Excel::load($path, function($reader){},'UTF-8')->get()->toArray();

                 //print_r($data);
                  //  exit();
                
                if(!empty($data) && count($data)){
                    foreach ($data as $key => $value) {
                        
                        $total=$model->getPrice($value['options'],$prices);

                        DB::table('tbl_orders')
                        ->insert($value+['price'=>$total]+['orderdate'=>date('Y-m-d')]);
                    }
                    
                    
                }
                return redirect('/uploads/excel')->with('status', 'Imported successfully!');
            }else{
                return redirect('/uploads/excel')->with('failed', 'Import Failed!');
            }
        }else{
             return redirect('/uploads/excel')->with('failed', 'Import Failed!');
        }
       // \Session::flash('flash_message','successfully saved.');
        
    
    }
    public function import_excel(){
        return View('excel_import.import_excel');
    }









    public function getProducts(){
        $table = "tbl_products";
        $model = new Api;
        $dta =$model->readData($table);
        return response()->json($dta);
    }
    


    


    

   
    public function deletedata($id){
        $table = "tbl_products";
        $model = new Api;
        $model->remove($table,$id);
    }
    public function updatedata(Request $request){
        $table = "tbl_products";
        $id=$request->id;
        $express=[
         "product_name" => $request->name,
         "price" => $request->price, 
         "qty" =>    $request->qty
        ];
        $model = new Api;
        $model->updateData($table,$id,$express);
        return redirect('/addnew');
    }


    public function editdata($id){
        $table = "tbl_products";
        $model = new Api;
        $data = $model->readEdit($table,$id);
        return response()->json($data[0]);
    }

    /////////////////////////// End Not Complete///////////////////////
    
}
