var app = angular.module('productRecords', ["LocalStorageModule","angularUtils.directives.dirPagination"],function($interpolateProvider) {
        $interpolateProvider.startSymbol('<%');
        $interpolateProvider.endSymbol('%>');
    });

var app1 = angular.module('sampleApp', [],function($interpolateProvider) {
        $interpolateProvider.startSymbol('<%');
        $interpolateProvider.endSymbol('%>');
    });
      