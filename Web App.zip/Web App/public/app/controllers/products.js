app.controller('productsController', function($scope,$http,localStorageService) {
    $http.get("/products")
    .success(function(response) {
        $scope.products = response;
    });


    //show modal form
    $scope.toggle = function(modalstate, id) {
        $scope.modalstate = modalstate;

        switch (modalstate) {
            case 'add':
                $scope.form_title = "Add New Products";
                break;
            case 'edit':
                $scope.form_title = "Products Detail";
                $scope.id = id;
                $http.get('/products/' + id +'/edit')
                        .success(function(response) {
                            console.log(JSON.stringify(response));
                            $scope.data = response;
                        });
                break;
            default:
                break;
        }
        //console.log(id);
        $('#myModal').modal('show');
    }


    // refresh data

    function refreshData(){
    	$http.get("/products")
		    .success(function(response) {
		        $scope.products = response;
		    });
    }

    $scope.test = function(){
    	console.log(JSON.stringify($scope.localStorage));
    }
    //save new record / update existing record
    $scope.save = function(modalstate, id) {
      	var url ="/products";

      	var token = $('meta[name="csrf-token"]').attr('content');
      	//append employee id to the URL if the form is in edit mode
        if (modalstate === 'edit'){
            url += "/update"
        }else{
        	url += "/save"
        	//alert('hello');
        }
        $http({
            method: 'POST',
            url: url,
            data: {"name": $scope.data.product_name, "price": $scope.data.price, "qty": $scope.data.qty,"_token": token,"id":$scope.data.id}
        }).success(function(response) {
            refreshData();
        }).error(function(response) {
            console.log(response);
            alert('This is embarassing. An error has occured. Please check the log for details');
        });
    }


    //delete record
    $scope.confirmDelete = function(id) {
        var isConfirmDelete = confirm('Are you sure you want this record?');
        if (isConfirmDelete) {
            $http({
                method: 'get',
                url: 'products/' + id + "/delete"
            }).
                    success(function(data) {
                       refreshData();
                    }).
                    error(function(data) {
                        console.log(data);
                        alert('Unable to delete');
                    });
        } else {
            return false;
        }
    }

});