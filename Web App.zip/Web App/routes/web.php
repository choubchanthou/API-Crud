<?php


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/media',"UploadController@home");
// upload file
Route::post('/file-upload','UploadController@uploadImage');
Route::get('/remove-file','UploadController@removeFile');
Route::get('/save-file','UploadController@saveFile');
Auth::routes();

Route::get('/', 'HomeController@index');



// route for user
//get route


Route::get('/{id}/delete/{table}',['uses' =>'HomeController@destory']);

Route::get('/add/{table}',['uses'=>'HomeController@openAdd']);

Route::get('/view/{table}',['uses'=>'HomeController@openView']);
Route::get('/{id}/edit/{table}',['uses' =>'HomeController@openEdit']);


Route::get('/ens',['uses'=>'HomeController@enc']);

//post route
Route::post('/save','HomeController@save');
Route::post('/update','HomeController@update');



/// Route Import excel

Route::get('/uploads/excel','HomeController@import_excel');
Route::post('/uploads/save','HomeController@imported');